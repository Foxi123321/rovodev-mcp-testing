---
agent: Plan
description: Iterate quicker on simple tasks
---
Planning for faster iteration: Research as usual, but draft a much more shorter implementation plan that focused on just the main steps
