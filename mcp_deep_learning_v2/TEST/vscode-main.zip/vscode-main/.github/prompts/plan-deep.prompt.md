---
agent: Plan
description: Clarify before planning in more detail
---
Before doing your research workflow, gather preliminary context using #runSubagent (instructed to use max 5 tool calls) to get a high-level overview.

Then ask 3 clarifying questions and PAUSE for the user to answer them.

AFTER the user has answered, start the <workflow>. Add extra details to your planning draft.
